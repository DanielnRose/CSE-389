<html>
<head>
	<title> Login </title>
	<meta name="viewpoint" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
</head>

<body>

<!-- login buttons-->
<div class = "login">
	<form action="process.php" method="post">
		
		<h1> SIGN IN</h1>
		<input id = "lname" type="text" name="username" placeholder="Username" required></br>
		<input id = "fname" type="password" name="password" placeholder="********" required></br>
		<input type="submit" value="Login">
		<br></br>
		<a href="signup.php">Sign up</a>


	</form>





</div>
</body>
</html>


