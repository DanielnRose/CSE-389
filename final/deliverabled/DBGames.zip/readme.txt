DB Games Readme

by Daniel Rose and Bikash Khatiwoda

--------------------------------------------------------------------------

First Install XAMPP and download the files

1. Download and install XAMPP from https://www.apachefriends.org/index.html

2. Go to where you installed XAMPP then to the htdocs folder

3. there create a folder called fp to put all the websites files into.

--------------------------------------------------------------------------

Next we have to setup the database

1. Run Apache and MySQL from the XAMPP dashboard

2. In a browser type the adress "localhost" to conect to the website

3. Click on phpMyAdmin on the top right

4. All the way on the left click on the new buton to create a new database

5. For name call it 'db1', keep the type default and click create.

6. Inside db1 click create table called 'user' with 4 coloms and click to go button to create.

8. Colum 1 should be called 'id' with type int with Length/Values being 11 and the A_I button should be checked and then click go.

7. Colum 2 should be called 'fname' with type string

7. Colum 3 should be called 'lname' with type string

8. Colum 4 should be called 'score' with type int and a default As Defined to 10

9. Once you have set each row click on save on the bottom right.

----------------------------------------------------------------------------

To run the website make sure Apache and MySQL are running from the XAMPP dashboard

Then go to a web browser and type localhost/fp to get to the login page

The website is best viewed on a 1080p screen but should work on any resolution.

You should now be all set up to use the website :)
