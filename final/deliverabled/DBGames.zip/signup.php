<html>
<head>
	
	<title>Sign up</title>
	<link rel="stylesheet" href="signup.css">

</head>

<body>
	
	<div class = "signup">
		<form action="submit.php" method="post">
			<h1>Sign Up</h1>
			<input type="text" name="username" placeholder="Name" required></br>
			<input type="password" name="password" placeholder="****" required></br>
			<input type="submit" value="Sign Up">
			<a href="index.php"> </a>
			<br></br>
			<a href="index.php">Login</a>

		</form>
	</div> 





</body>
</html>